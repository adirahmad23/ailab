<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2023 &copy; AiLab</p>
        </div>
        <div class="float-end">
            <!-- <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a
                href="https://saugi.me">Saugi</a></p> -->
        </div>
    </div>
</footer>
</div>
</div>

<script src="assets/js/bootstrap.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/extensions/simple-datatables/umd/simple-datatables.js"></script>
<script src="assets/js/pages/simple-datatables.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/select2.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>